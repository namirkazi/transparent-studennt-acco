# Accomodation_finder

link:  https://namanbansal.000webhostapp.com

This website makes it easier to find proper accommodation in different areas according to people's requirements.
This will be especially beneficial to the college students who are in search of an accommodation.
This will create a proper database of all the proper living accommodations nearby various institutes. 
This website will be helpful to the people coming from out of town, they won’t have to roam around in search for a proper accommodation.
Different owners can list their PG/Hostel on the website with complete specifications of rooms available. 
If the project is successful, it will lead to an increase in the competition and decrease in the prices of the Hostels/PGs.

I am using mysql for database, php for backend, javascript, bootstrap and html for front-end. 

Steps to run the project 

1. Run the createtable1.php file to setup the database.
2. change the credentials in dbconnect file according to the database.
3. host the website on hostinger or aws or run on localhost using xampp or apache.
