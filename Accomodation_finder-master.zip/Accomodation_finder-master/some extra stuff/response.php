
<?php

$test = $_GET['var_PHP_data'];
echo "variable is : .$test";

?>